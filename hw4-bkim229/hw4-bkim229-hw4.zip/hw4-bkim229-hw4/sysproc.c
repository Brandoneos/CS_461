#include "types.h"
#include "x86.h"
#include "defs.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
#include "proc.h"
#include "spinlock.h"
#include "sleeplock.h"
#include "fs.h"
#include "file.h"

int sys_fork(void)
{
  return fork();
}

int sys_exit(void)
{
  exit();
  return 0; // not reached
}

int sys_wait(void)
{
  return wait();
}

int sys_kill(void)
{
  int pid;

  if (argint(0, &pid) < 0)
    return -1;
  return kill(pid);
}

int sys_getpid(void)
{
  return proc->pid;
}

addr_t
sys_sbrk(void)
{
  addr_t addr;
  addr_t n;

  argaddr(0, &n);
  addr = proc->sz;
  if (growproc(n) < 0)
    return -1;
  return addr;
}

int sys_sleep(void)
{
  int n;
  uint ticks0;

  if (argint(0, &n) < 0)
    return -1;
  acquire(&tickslock);
  ticks0 = ticks;
  while (ticks - ticks0 < n)
  {
    if (proc->killed)
    {
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
  }
  release(&tickslock);
  return 0;
}

// return how many clock tick interrupts have occurred
// since start.
int sys_uptime(void)
{
  uint xticks;

  acquire(&tickslock);
  xticks = ticks;
  release(&tickslock);
  return xticks;
}

#define MMAP_FAILED ((~0lu))
addr_t
sys_mmap(void)
{
  int fd, flags;
  if (argint(0, &fd) < 0 || argint(1, &flags) < 0)
    return MMAP_FAILED;
  if (flags == 0)
  {
    // eager:
    struct file *f2;
    if (fd < 0 || fd >= NOFILE || (f2 = proc->ofile[fd]) == 0)
    {
      cprintf("Error in argfd\n");
      return MMAP_FAILED;
    }

    int n;
    n = f2->ip->size;
    addr_t previousTop = (addr_t)proc->mmaptop;
    char *mem;
    addr_t a1 = 0;
    for (; a1 < PGROUNDUP(n); a1 += PGSIZE)
    {

      mem = kalloc(); // allocates a page of physical memory
      if (mem == 0)
      {
        kfree(mem);
        return 0;
      }
      memset(mem, 0, PGSIZE);
      //called 18 times
      if (mappages(proc->pgdir, proc->mmaptop, PGSIZE, V2P(mem), PTE_W | PTE_U) < 0)
      {
        // creates pte for virtual memory to physical memory
        kfree(mem);
        return 0; // panic?
      }
      proc->mmaptop += PGSIZE;
    }
    fileread(f2, (char *)previousTop, n);
    for (int i = 0; i < 10; i++)
    {
      if (proc->mmaps[i].fd == -1)
      {
        proc->mmaps[i].fd = fd;
        proc->mmaps[i].start = previousTop;
        break;
      }
    }
    proc->mmapcount++;
    return previousTop;
  }
  else if (flags == 1)
  {
    // lazy:
    struct file *f2;
    if (fd < 0 || fd >= NOFILE || (f2 = proc->ofile[fd]) == 0)
    {
      cprintf("Error in argfd\n");
      return MMAP_FAILED;
    }
    int n;
    n = f2->ip->size;
    addr_t previousTop = (addr_t)proc->mmaptop;
    addr_t a1 = 0;
    for (; a1 < PGROUNDUP(n); a1 += PGSIZE)
    {
      proc->mmaptop += PGSIZE; // only update mmaptop to simulate that we mapped it
    }
    for (int i = 0; i < 10; i++)
    {
      if (proc->mmaps[i].fd == -1)
      {
        proc->mmaps[i].fd = fd;
        proc->mmaps[i].start = previousTop;
        break;
      }
    }
    proc->mmapcount++;

    return previousTop;
  }
  return MMAP_FAILED;
}
/*
struct proc {
  addr_t sz;                   // Size of process memory (bytes)
  pde_t* pgdir;                // Page table
  char *kstack;                // Bottom of kernel stack for this process
  enum procstate state;        // Process state
  int pid;                     // Process ID
  struct proc *parent;         // Parent process
  struct trapframe *tf;        // Trap frame for current syscall
  struct context *context;     // swtch() here to run process
  void *chan;                  // If non-zero, sleeping on chan
  int killed;                  // If non-zero, have been killed
  struct file *ofile[NOFILE];  // Open files
  struct inode *cwd;           // Current directory
  char name[16];               // Process name (debugging)

  // mmap
  char* mmaptop;
  int mmapcount; // number of mmaps recorded below
  struct {
    int fd;
    addr_t start;
  } mmaps[10];
};
 */
pte_t *
walkpgdir(pde_t *pml4, const void *va, int alloc)
{
  pml4e_t *pml4e;
  pdpe_t *pdp, *pdpe;
  pde_t *pde, *pd, *pgtab;

  // from the PML4, find or allocate the appropriate PDP table
  pml4e = &pml4[PMX(va)];
  if(*pml4e & PTE_P)
    pdp = (pdpe_t*)P2V(PTE_ADDR(*pml4e));
  else {
    if(!alloc || (pdp = (pdpe_t*)kalloc()) == 0)
      return 0;
    memset(pdp, 0, PGSIZE);
    *pml4e = V2P(pdp) | PTE_P | PTE_W | PTE_U;
  }

  //from the PDP, find or allocate the appropriate PD (page directory)
  pdpe = &pdp[PDPX(va)];
  if(*pdpe & PTE_P)
    pd = (pde_t*)P2V(PTE_ADDR(*pdpe));
  else {
    if(!alloc || (pd = (pde_t*)kalloc()) == 0)//allocate page table
      return 0;
    memset(pd, 0, PGSIZE);
    *pdpe = V2P(pd) | PTE_P | PTE_W | PTE_U;
  }

  // from the PD, find or allocate the appropriate page table
  pde = &pd[PDX(va)];
  if(*pde & PTE_P)
    pgtab = (pte_t*)P2V(PTE_ADDR(*pde));
  else {
    if(!alloc || (pgtab = (pte_t*)kalloc()) == 0)//allocate page table
      return 0;
    memset(pgtab, 0, PGSIZE);
    *pde = V2P(pgtab) | PTE_P | PTE_W | PTE_U;
  }

  return &pgtab[PTX(va)];
}

int handle_pagefault(addr_t va)
{
  // TODO: your code here
  // need for lazy solution
  // va is the address the user wanted to access but failed
  // first address is 0x000..4000..55 because 0x55 is 85, and text is char[85]

  addr_t topOfAddress;
  int fd;
  for (int i = 9; i >= 0; i--)
  {
    if (proc->mmaps[i].start <= va && proc->mmaps[i].fd != -1)
    {
      topOfAddress = proc->mmaps[i].start;
      fd = proc->mmaps[i].fd;
      break;
    }
  }

  // now we have top of address needed. Now we need to
  //  allocate from top of address to the va
  struct file *f2;
  if (fd < 0 || fd >= NOFILE || (f2 = proc->ofile[fd]) == 0)
  {
    cprintf("Error in argfd\n");
    return -1;
  }
  char *mem;
  char *topPointer = (char *)PGROUNDDOWN(va);
    pte_t *pte = walkpgdir(proc->pgdir, topPointer, 0); // Do not create if missing
    // pte_t * walkpgdir(pde_t *pml4, const void *va, int alloc)
    if (pte && (*pte & PTE_P))
    {
      // if location is already mapped, don't map it
    }
    else
    {                 // map it, and allocate
      mem = kalloc(); // allocates a page of physical memory
      if (mem == 0)
      {
        kfree(mem);
        return 0;
      }
      memset(mem, 0, PGSIZE);
      if (mappages(proc->pgdir, topPointer, PGSIZE, V2P(mem), PTE_W | PTE_U) < 0)
      {
        // creates pte for virtual memory to physical memory
        kfree(mem);
        return 0; // panic?
      }
    }
  int r;
  int diff3 = (int)((int)topPointer - (int)topOfAddress);
  ilock(f2->ip);
  if((r = readi(f2->ip, (char *)topPointer, diff3, PGSIZE)) > 0)
    diff3 += r;
  iunlock(f2->ip);
  return 1;
}
